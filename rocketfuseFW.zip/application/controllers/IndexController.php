<?php

Loader::import('Module', 'FormValidator');

class IndexController extends Controller {
	
	public function index($param1=null) {
		
		$rules = array(
	        'username' => array(
	            'rule' => array('isValidAlphaNumeric'),
	            'message' => 'You have not entered your name.'
	        ),
	        'email' => array(
	            'rule' => 'isValidEmail',
	            'message' => 'You have entered an invalid e-mail address.'
	        ),
	        'password' => array(
	            'rule' => 'isValidAlphaNumeric',
	            'message' => 'You did not enter a message.'
	        )
		);
		
		$validator = new FormValidator($rules, $_POST);
		
		//$this->findAllUsers();
		$this->App->Template->title = "Index Controller";
		$this->App->Template->render('hello');
	}
	
	private function createPost(){
		$post = new Post();
		$post->setTitle("Blehhhhhhhhhhhh");
		$post->setUserId(1);
		$post->setPriceFrom(5000);
		$post->setPriceTo(10000);
		$post->save();
	}
	
	private function findAllUsers() {
		$users = UserQuery::create()->find();

		foreach($users as $user) {
			echo $user->getEmail() . "<br>";
		}
	}
	
	public function test() {
		$this->App->Template->title = "Index Controller: test()";
		$this->App->Template->render('hello');
	}

}

?>