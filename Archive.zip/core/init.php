<?php

/*
*	BootStrapper File, loads all core files, models and controllers on request including Propel ORM
*/

/* Framework Core File Loading*/
require_once(__ROOT . DS . 'core' . DS . 'Loader.php');

//Application Directory Include path
set_include_path(__ROOT . PATH_SEPARATOR . get_include_path());

/* PROPEL BOOTSTRAP*/
require_once(\core\Loader::convertPath('vendors/propel/runtime/lib/Propel.php'));
Propel::init(\core\Loader::convertPath('application/schema/build/conf/models-conf.php'));
set_include_path(\core\Loader::convertPath('application/schema/build/classes') . PATH_SEPARATOR . get_include_path());
/* END PROPEL BOOTSTRAP*/

//set the vendors path
set_include_path(\core\Loader::convertPath('vendors') . PATH_SEPARATOR . get_include_path());

//include the core files
set_include_path(\core\Loader::convertPath('core') . PATH_SEPARATOR . get_include_path());

$loader = new \core\Loader("core", __ROOT);
$loader->register();

$loader = new \core\Loader(null, 'application/schema/build/classes/models/map');
$loader->register();

$loader = new \core\Loader(null, 'application/schema/build/classes/models/om');
$loader->register();

$loader = new \core\Loader(null, 'application/schema/build/classes/models');
$loader->register();



?>