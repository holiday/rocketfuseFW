<?php

Loader::import('Module', 'FormValidator');

class IndexController extends Controller {
	
	public function index($param1=null) {
		
		$this->App->Template->title = "Index Controller";
		$this->App->Template->render('hello');
	}
	
	private function createPost(){
		$post = new Post();
		$post->setTitle("Blehhhhhhhhhhhh");
		$post->setUserId(1);
		$post->setPriceFrom(5000);
		$post->setPriceTo(10000);
		$post->save();
	}
	
	private function findAllUsers() {
		$users = UserQuery::create()->find();

		foreach($users as $user) {
			echo $user->getEmail() . "<br>";
		}
	}
	
	public function creditCard() {
		
		if($_SERVER['REQUEST_METHOD'] == "POST"){
			
			$rules = array(
		        'cc' => array(
		            'rule' => array('creditcard', $_POST['cardtype']),
		            'message' => 'Invalid Credit Card number. Please retry.'
		        )
			);
			
			$val = new FormValidator($rules, $_POST);
			if($val->validate()) {
				echo "Valid Card!<br>";
			}else {
				echo "invalid card";
			}
		}
		
		$this->App->Template->title = "Credit Card Checker";
		$this->App->Template->render('random');
	}

}

?>