<?php

//Relative path for the application
define('__ROOT', realpath(dirname(__FILE__)));

//Require main config file
require_once( __ROOT . DIRECTORY_SEPARATOR . 'core' . DIRECTORY_SEPARATOR . 'config.php');

?>